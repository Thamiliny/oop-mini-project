/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.assignment.product_management_system;

import View.Login;

/**
 *
 * @author ASUS
 */
public class Product_Management_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Login login = new Login();
                login.setVisible(true);
    }
}
