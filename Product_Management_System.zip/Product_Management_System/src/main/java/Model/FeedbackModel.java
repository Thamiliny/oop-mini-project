///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Model;
//
///**
// *
// * @author ASUS
// */
//
//
//
//import Project.ConnectionProvider;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//public class FeedbackModel {
//    
//    public boolean saveFeedback(String fullName, String subject, String message) {
//        try {
//            Connection con = ConnectionProvider.getCon();
//            String query = "INSERT INTO feedback (fullName, subject, message) VALUES (?, ?, ?)";
//            PreparedStatement pstmt = con.prepareStatement(query);
//            pstmt.setString(1, fullName);
//            pstmt.setString(2, subject);
//            pstmt.setString(3, message);
//            
//            int rowsAffected = pstmt.executeUpdate();
//            
//            return rowsAffected > 0;
//            
//        } catch (SQLException e) {
//            System.out.println("Error: " + e.getMessage());
//            return false;
//        }
//    }
//    
//}






package Model;

import Project.ConnectionProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FeedbackModel {

    private int id;
    private String fullName;
    private String subject;
    private String message;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // Additional method to set all attributes
    public void setAll(int id, String fullName, String subject, String message) {
        this.id = id;
        this.fullName = fullName;
        this.subject = subject;
        this.message = message;
    }
}
