///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Model;
//
///**
// *
// * @author ASUS
// */
//
//import Project.ConnectionProvider;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import javax.swing.table.DefaultTableModel;
//
//public class CustomerModel {
//
//    public boolean addCustomer(String firstName, String lastName, String address, String email, String phone, String gender) {
//        try {
//            Connection con = ConnectionProvider.getCon();
//            PreparedStatement ps = con.prepareStatement("INSERT INTO customers (first_name, last_name, address, email, phone, gender) VALUES (?, ?, ?, ?, ?, ?)");
//            ps.setString(1, firstName);
//            ps.setString(2, lastName);
//            ps.setString(3, address);
//            ps.setString(4, email);
//            ps.setString(5, phone);
//            ps.setString(6, gender);
//            ps.executeUpdate();
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
//
//    public DefaultTableModel getAllCustomers() {
//        DefaultTableModel model = new DefaultTableModel(new String[]{"Customer ID", "First Name", "Last Name", "Address", "Email", "Phone", "Gender"}, 0);
//        try {
//            Connection con = ConnectionProvider.getCon();
//            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers");
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                model.addRow(new Object[]{
//                    rs.getInt("customer_id"),
//                    rs.getString("first_name"),
//                    rs.getString("last_name"),
//                    rs.getString("address"),
//                    rs.getString("email"),
//                    rs.getString("phone"),
//                    rs.getString("gender")
//                });
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return model;
//    }
//
//    public DefaultTableModel searchCustomers(String searchTerm) {
//        DefaultTableModel model = new DefaultTableModel(new String[]{"Customer ID", "First Name", "Last Name", "Address", "Email", "Phone", "Gender"}, 0);
//        try {
//            Connection con = ConnectionProvider.getCon();
//            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE customer_id = ?");
//            ps.setString(1, searchTerm);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                model.addRow(new Object[]{
//                    rs.getInt("customer_id"),
//                    rs.getString("first_name"),
//                    rs.getString("last_name"),
//                    rs.getString("address"),
//                    rs.getString("email"),
//                    rs.getString("phone"),
//                    rs.getString("gender")
//                });
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return model;
//    }
//
//    public boolean deleteCustomer(String customerId) {
//        try {
//            Connection con = ConnectionProvider.getCon();
//            PreparedStatement ps = con.prepareStatement("DELETE FROM customers WHERE customer_id = ?");
//            ps.setString(1, customerId);
//            ps.executeUpdate();
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
//}





package Model;

import Project.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class CustomerModel {

    public boolean addCustomer(String firstName, String lastName, String address, String email, String phone, String gender) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("INSERT INTO customers (first_name, last_name, address, email, phone, gender) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, address);
            ps.setString(4, email);
            ps.setString(5, phone);
            ps.setString(6, gender);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public DefaultTableModel getAllCustomers() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Customer ID", "First Name", "Last Name", "Address", "Email", "Phone", "Gender"}, 0);
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("address"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("gender")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }

    public DefaultTableModel searchCustomers(String searchTerm) {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Customer ID", "First Name", "Last Name", "Address", "Email", "Phone", "Gender"}, 0);
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE id = ?");
            ps.setString(1, searchTerm);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("address"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("gender")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }

    public boolean deleteCustomer(String customerId) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("DELETE FROM customers WHERE id = ?");
            ps.setString(1, customerId);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
