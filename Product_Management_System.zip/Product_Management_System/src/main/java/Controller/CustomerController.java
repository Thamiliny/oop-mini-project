///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Controller;
//
///**
// *
// * @author ASUS
// */
//
//
//
//import Model.CustomerModel;
//
//public class CustomerController {
//    private CustomerModel model;
//
//    public CustomerController() {
//        this.model = new CustomerModel();
//    }
//
//    public boolean addCustomer(String firstName, String lastName, String address, String email, String phone, String gender) {
//        return model.addCustomer(firstName, lastName, address, email, phone, gender);
//    }
//
//    public void displayAllCustomers(javax.swing.JTable table) {
//        table.setModel(model.getAllCustomers());
//    }
//
//    public void searchCustomer(String searchTerm, javax.swing.JTable table) {
//        table.setModel(model.searchCustomers(searchTerm));
//    }
//
//    public void deleteCustomer(String customerId, javax.swing.JTable table) {
//        boolean success = model.deleteCustomer(customerId);
//        if (success) {
//            javax.swing.JOptionPane.showMessageDialog(null, "Customer deleted successfully.");
//            displayAllCustomers(table);
//        } else {
//            javax.swing.JOptionPane.showMessageDialog(null, "Failed to delete customer.");
//        }
//    }
//}






package Controller;

import Model.CustomerModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CustomerController {

    private CustomerModel model;

    public CustomerController() {
        this.model = new CustomerModel();
    }

    public boolean addCustomer(String firstName, String lastName, String address, String email, String phone, String gender) {
        return model.addCustomer(firstName, lastName, address, email, phone, gender);
    }

    public void displayAllCustomers(JTable table) {
        table.setModel(model.getAllCustomers());
    }

    public void searchCustomer(String searchTerm, JTable table) {
        table.setModel(model.searchCustomers(searchTerm));
    }

    public void deleteCustomer(String customerId, JTable table) {
    boolean success = model.deleteCustomer(customerId);
    if (success) {
        javax.swing.JOptionPane.showMessageDialog(null, "Customer deleted successfully.");
        displayAllCustomers(table); // Refresh the table after deletion
    } else {
        javax.swing.JOptionPane.showMessageDialog(null, "Failed to delete customer.");
    }
}

}