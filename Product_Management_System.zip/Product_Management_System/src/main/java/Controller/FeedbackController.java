///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Controller;
//
///**
// *
// * @author ASUS
// */
//
//
//import Model.FeedbackModel;
//import Project.ConnectionProvider;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//public class FeedbackController {
//
//    public boolean saveFeedback(String fullName, String subject, String message) {
//        try (Connection con = ConnectionProvider.getCon();
//             PreparedStatement pst = con.prepareStatement("INSERT INTO feedback (fullName, subject, message) VALUES (?, ?, ?)")) {
//
//            pst.setString(1, fullName);
//            pst.setString(2, subject);
//            pst.setString(3, message);
//
//            int rowsInserted = pst.executeUpdate();
//            return rowsInserted > 0;
//
//        } catch (SQLException e) {
//            e.printStackTrace(); // Print the stack trace to understand the error
//            return false;
//        }
//    }
//}






package Controller;

import Model.FeedbackModel;
import Project.ConnectionProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FeedbackController {

    public boolean saveFeedback(String fullName, String subject, String message) {
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement("INSERT INTO feedback (fullName, subject, message) VALUES (?, ?, ?)")) {

            pst.setString(1, fullName);
            pst.setString(2, subject);
            pst.setString(3, message);

            int rowsInserted = pst.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<FeedbackModel> getAllFeedbacks() {
        List<FeedbackModel> feedbackList = new ArrayList<>();

        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM feedback");
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                FeedbackModel feedback = new FeedbackModel();
                feedback.setId(rs.getInt("id"));
                feedback.setFullName(rs.getString("fullName"));
                feedback.setSubject(rs.getString("subject"));
                feedback.setMessage(rs.getString("message"));
                feedbackList.add(feedback);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return feedbackList;
    }

    public FeedbackModel getFeedbackById(int id) {
        FeedbackModel feedback = null;

        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM feedback WHERE id = ?")) {

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                feedback = new FeedbackModel();
                feedback.setId(rs.getInt("id"));
                feedback.setFullName(rs.getString("fullName"));
                feedback.setSubject(rs.getString("subject"));
                feedback.setMessage(rs.getString("message"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return feedback;
    }

    public boolean deleteFeedbackById(int id) {
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement("DELETE FROM feedback WHERE id = ?")) {

            pst.setInt(1, id);
            int rowsDeleted = pst.executeUpdate();
            return rowsDeleted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
